//
//  FibonacciApp.swift
//  Fibonacci
//
//  Created by Jeniffer Calderón on 10/03/23.
//

import SwiftUI

@main
struct FibonacciApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
