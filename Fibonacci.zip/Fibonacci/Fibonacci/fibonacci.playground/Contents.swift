import Foundation
import UIKit
import SwiftUI


//Escribe un programa que, dado un número, compruebe y muestre si es primo,
//* fibonacci y par.
//* Ejemplos:
//* - Con el número 2, nos dirá: "2 es primo, fibonacci y es par"
//* - Con el número 7, nos dirá: "7 es primo, no es fibonacci y es impar"


var num : Int
public var nuevoValor: Int?

num=8 //Aplica para valores mayores a 4

func fib (num: Int)  {
    // haciendo la serie de Fibonacci
    // valor inicial de la serie
    var valorInit:Int = 1;
    // valor del segundo elemento de la serie
    var valorNext:Int = 1;
    
    print("Serie de Fibonacci")
    print("==================")
    
    // Ciclo que repite x veces el cáculo, más de x se cae el framework
    for  i in 1...num  {
        // Solo imprime el valor 1 para el primer y segundo elemento de la serie
        if ( i < 3 ) {
            //print("\(i) 1")
        }else  {
            var nuevoValor = valorInit + valorNext;
            //print("\(i) \(nuevoValor)")
            valorInit = valorNext
            valorNext = nuevoValor

            
            
        }
        var arregloFib: [Int] = [i]
        arregloFib.append(valorNext)
        print(arregloFib[1])
        
        
        if arregloFib[1]  == num {
            print( "\(arregloFib [1]) es un número fibonacci ")
        }
    }


        
}
 

    
var  numFib = Int(num)
fib(num: numFib)
    
print("")
print("")
print("Tipo de número")
print("______________")

if numFib % 2 == 0  {
        print("\(numFib) es par")
}else {
        print("\(numFib) es impar")
}
    
    
    


